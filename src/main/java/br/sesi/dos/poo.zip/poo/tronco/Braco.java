package br.sesi.dos.poo.tronco;

public class Braco {
    int qtdeDedosMao;
    boolean bracoAmputado;
}
