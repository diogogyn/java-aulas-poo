package br.sesi.dos.poo.tronco;

public class Tronco {
    Braco bracoEsquerdo;
    Braco bracoDireito;
}
