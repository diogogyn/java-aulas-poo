package br.sesi.dos.poo.cabeca;

public class Olho {
    public String corIris;
    public float diametroOlho;
    public boolean cego;
}
