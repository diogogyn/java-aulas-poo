package br.sesi.dos.poo.cabeca;

public class Orelha {
    float tamanhoOrelha;
    int qtdeOrelhas;
}
