package br.sesi.dos.poo.cabeca;

public class Nariz {
    float tamanhoNariz;
}
