package br.sesi.dos.poo.cabeca;

public class Boca {
    String corLabios;
    int qtdeDentes;
}
