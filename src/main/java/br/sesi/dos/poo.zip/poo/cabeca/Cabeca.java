package br.sesi.dos.poo.cabeca;

public class Cabeca {
    public Olho olho;
    public Orelha orelhao;
    public Nariz nariz;
    public Boca boca;
}
