package br.sesi.dos.poo;

public class Main {

    public static void main(String[] args) {
        Pessoa pessoa1 = new Pessoa();
        pessoa1.cabeca.olho.corIris = "marrom";


    }
}
